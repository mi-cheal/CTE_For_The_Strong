import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Scanner {
    private static final String KEYWORD_PATTERN = "\\b(?:INTEGER|ASSIGN|READ|WRITE|START|STOP)\\b";
    private static final String IDENTIFIER_PATTERN = "\\b([A-Za-z]|[A-Za-z][A-Za-z0-9]*)\\b";
    private static final String OPERATOR_PATTERN = "\\b(?:\\+|-|/|\\*)\\b";
    private static final String SYMBOL_PATTERN = "\\b(?:=|;)\\b";

    private static final Map<String, TokenType> KEYWORDS = new HashMap<>();

    static {
        KEYWORDS.put("INTEGER", TokenType.INTEGER);
        KEYWORDS.put("ASSIGN", TokenType.ASSIGN);
        KEYWORDS.put("READ", TokenType.READ);
        KEYWORDS.put("WRITE", TokenType.WRITE);
        KEYWORDS.put("START", TokenType.START);
        KEYWORDS.put("STOP", TokenType.STOP);
    }

    public static List<Token> scan(String input) {
        List<Token> tokens = new ArrayList<>();
        String[] lines = input.split("\n");

        for (int lineNumber = 0; lineNumber < lines.length; lineNumber++) {
            String line = lines[lineNumber];
            int position = 0;

            while (position < line.length()) {
                Token token = getNextToken(line, position, lineNumber + 1);
                if (token != null) {
                    tokens.add(token);
                    position += token.getValue().length();
                } else {
                    throw new IllegalStateException("Invalid character at line " + (lineNumber + 1) + ", position " + (position + 1));
                }
            }
        }

        return tokens;
    }

    private static Token getNextToken(String line, int position, int lineNumber) {
        String remaining = line.substring(position);

        // Check for keywords
        Matcher keywordMatcher = Pattern.compile(KEYWORD_PATTERN).matcher(remaining);
        if (keywordMatcher.lookingAt()) {
            String value = keywordMatcher.group();
            return new Token(KEYWORDS.get(value), value, lineNumber);
        }

        // Check for identifiers
        Matcher identifierMatcher = Pattern.compile(IDENTIFIER_PATTERN).matcher(remaining);
        if (identifierMatcher.lookingAt()) {
            String value = identifierMatcher.group();
            return new Token(TokenType.IDENTIFIER, value, lineNumber);
        }

        // Check for operators
        Matcher operatorMatcher = Pattern.compile(OPERATOR_PATTERN).matcher(remaining);
        if (operatorMatcher.lookingAt()) {
            String value = operatorMatcher.group();
            return new Token(TokenType.OPERATOR, value, lineNumber);
        }

        // Check for symbols
        Matcher symbolMatcher = Pattern.compile(SYMBOL_PATTERN).matcher(remaining);
        if (symbolMatcher.lookingAt()) {
            String value = symbolMatcher.group();
            return new Token(TokenType.SYMBOL, value, lineNumber);
        }

        return null;
    }
}