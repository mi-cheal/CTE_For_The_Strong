import java.util.List;

public class Main {
    public static void main(String[] args) {
        String input = "START\n" +
                       "INTEGER M, N, K, P, R, H, I, g, k, m\n" +
                       "READ M, N, K\n" +
                       "ASSIGN N = M - K\n" +
                       "READ g, H, I, m\n" +
                       "P = g / H - I + m * N / k\n" +
                       "R = M + N / K\n" +
                       "WRITE P\n" +
                       "STOP";

        List<Token> tokens = Scanner.scan(input);
        Parser parser = new Parser(tokens);
        parser.parse();

        SemanticAnalyzer semanticAnalyzer = new SemanticAnalyzer(tokens);
        semanticAnalyzer.analyze();

        IntermediateCodeGenerator icGenerator = new IntermediateCodeGenerator(tokens);
        List<String> intermediateCode = icGenerator.generateIntermediateCode();

        CodeGenerator codeGenerator = new CodeGenerator(intermediateCode);
        codeGenerator.generateCode();
    }
}