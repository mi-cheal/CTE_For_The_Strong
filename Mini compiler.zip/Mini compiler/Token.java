enum TokenType {
    INTEGER, ASSIGN, READ, WRITE, START, STOP, IDENTIFIER, OPERATOR, SYMBOL
}

class Token {
    private final TokenType type;
    private final String value;
    private final int lineNumber;

    Token(TokenType type, String value, int lineNumber) {
        this.type = type;
        this.value = value;
        this.lineNumber = lineNumber;
    }

    public TokenType getType() {
        return type;
    }

    public String getValue() {
        return value;
    }

    public int getLineNumber() {
        return lineNumber;
    }

    @Override
    public String toString() {
        return "Token{" +
                "type=" + type +
                ", value='" + value + '\'' +
                ", lineNumber=" + lineNumber +
                '}';
    }
}