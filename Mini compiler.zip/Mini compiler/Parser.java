import java.util.List;

public class Parser {
    private List<Token> tokens;
    private int position;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
        this.position = 0;
    }

    public void parse() {
        E();
    }

    private void E() {
        if (match(TokenType.IDENTIFIER)) {
            E1();
        } else {
            throw new RuntimeException("Expected identifier at line " + currentToken().getLineNumber());
        }
    }

    private void E1() {
        if (match(TokenType.OPERATOR, "+")) {
            E();
            E();
        } else if (match(TokenType.OPERATOR, "-")) {
            E();
            E();
        } else if (match(TokenType.OPERATOR, "/")) {
            E();
            E();
        } else if (match(TokenType.OPERATOR, "*")) {
            E();
            E();
        } else {
            // No operator, move on to the next rule
        }
    }

    private boolean match(TokenType type) {
        if (currentToken().getType() == type) {
            position++;
            return true;
        }
        return false;
    }

    private boolean match(TokenType type, String value) {
        if (currentToken().getType() == type && currentToken().getValue().equals(value)) {
            position++;
            return true;
        }
        return false;
    }

    private Token currentToken() {
        if (position >= tokens.size()) {
            return new Token(TokenType.SYMBOL, "", 0);
        }
        return tokens.get(position);
    }
}