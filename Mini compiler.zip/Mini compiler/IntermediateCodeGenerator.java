import java.util.ArrayList;
import java.util.List;

public class IntermediateCodeGenerator {
    private List<Token> tokens;
    private List<String> intermediateCode;

    public IntermediateCodeGenerator(List<Token> tokens) {
        this.tokens = tokens;
        this.intermediateCode = new ArrayList<>();
    }

    public List<String> generateIntermediateCode() {
        int i = 0;
        while (i < tokens.size()) {
            Token token = tokens.get(i);

            if (token.getType() == TokenType.IDENTIFIER) {
                String op1 = token.getValue();
                i++;

                if (i < tokens.size() && tokens.get(i).getType() == TokenType.OPERATOR) {
                    String op = tokens.get(i).getValue();
                    i++;

                    if (i < tokens.size() && tokens.get(i).getType() == TokenType.IDENTIFIER) {
                        String op2 = tokens.get(i).getValue();
                        i++;

                        String result = generateTemporaryVariable();
                        intermediateCode.add(result + " = " + op1 + " " + op + " " + op2);
                    } else {
                        throw new RuntimeException("Expected identifier after operator at line " + tokens.get(i - 1).getLineNumber());
                    }
                } else {
                    // Handle other cases as needed
                }
            } else {
                // Handle other cases as needed
            }
        }

        return intermediateCode;
    }

    private String generateTemporaryVariable() {
        return "t" + (intermediateCode.size() + 1);
    }
}