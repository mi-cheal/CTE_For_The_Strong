import java.util.List;

public class CodeGenerator {
    private List<String> intermediateCode;

    public CodeGenerator(List<String> intermediateCode) {
        this.intermediateCode = intermediateCode;
    }

    public void generateCode() {
        for (String instruction : intermediateCode) {
            generateInstruction(instruction);
        }
    }

    private void generateInstruction(String instruction) {
        String[] parts = instruction.split(" = ");
        String result = parts[0];
        String expression = parts[1];

        // Generate code for the expression
        // ...

        // Store the result
        System.out.println("istore " + getTemporaryVariableIndex(result));
    }

    private int getTemporaryVariableIndex(String variable) {
        return Integer.parseInt(variable.substring(1));
    }
}