import java.util.List;

public class SemanticAnalyzer {
    private List<Token> tokens;

    public SemanticAnalyzer(List<Token> tokens) {
        this.tokens = tokens;
    }

    public void analyze() {
        for (int i = 0; i < tokens.size(); i++) {
            Token token = tokens.get(i);

            switch (token.getType()) {
                case IDENTIFIER:
                    checkIdentifier(token);
                    break;
                case OPERATOR:
                    checkOperator(token, i);
                    break;
                case SYMBOL:
                    checkSymbol(token);
                    break;
                case INTEGER:
                    // Integers are not allowed
                    throw new RuntimeException("Integers are not allowed at line " + token.getLineNumber());
                // Add more cases for other token types as needed
                default:
                    break;
            }
        }
    }

    private void checkIdentifier(Token token) {
        if (token.getValue().length() == 1 && !Character.isLetter(token.getValue().charAt(0))) {
            throw new RuntimeException(
                    "Invalid identifier '" + token.getValue() + "' at line " + token.getLineNumber());
        }
    }

    private void checkOperator(Token token, int position) {
        if (position > 0 && tokens.get(position - 1).getType() == TokenType.OPERATOR) {
            throw new RuntimeException("Two operators cannot be combined at line " + token.getLineNumber());
        }
    }

    private void checkSymbol(Token token) {
        if (token.getValue().equals(";")) {
            throw new RuntimeException(
                    "Semicolon at the end of a line is not allowed at line " + token.getLineNumber());
        }
    }
}